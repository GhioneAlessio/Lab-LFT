Progetto Linguaggi Formali e Traduttori di:
Frattarola Marco
Ghione Alessio

La cartella "Traduttore_2" corrisponde alla consegna opzionale 5.2